// FILE: HUDPanel.h

#import <Cocoa/Cocoa.h>

@interface HUDPanel : NSPanel
@end
